package com.whitesoul.xiuxiantalent.talent.sub

import com.whitesoul.xiuxiantalent.instance
import org.bukkit.Bukkit
import org.bukkit.attribute.Attribute
import org.bukkit.entity.Player
import org.bukkit.event.Listener
import org.bukkit.potion.PotionEffect
import org.bukkit.potion.PotionEffectType
import org.bukkit.scheduler.BukkitTask
import java.util.*

object YouNiJianXiaoZhe: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register() {
        Bukkit.getScheduler().runTaskTimer(instance!!, Runnable {
            cache.forEach { uuid ->
                val player = Bukkit.getPlayer(uuid)
                if (player != null) {
                    increasePlayerAttackPower(player)
                    player.addPotionEffect(PotionEffect(PotionEffectType.BLINDNESS, Int.MAX_VALUE, 0, false, false))
                }
            }
        }, 20L, 20L)
    }

    private fun increasePlayerAttackPower(player: Player) {
        val attribute = player.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE)
        attribute?.baseValue = attribute?.baseValue?.plus(20)!!
        player.maxHealth = player.maxHealth + 500
        player.health = player.maxHealth
    }
}