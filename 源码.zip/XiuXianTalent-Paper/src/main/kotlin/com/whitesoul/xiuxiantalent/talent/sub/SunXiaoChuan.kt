package com.whitesoul.xiuxiantalent.talent.sub

import com.whitesoul.xiuxiantalent.data.PlayerData
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.entity.EntityDamageByEntityEvent
import org.bukkit.scheduler.BukkitTask
import java.util.*

object SunXiaoChuan:Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }

    @EventHandler
    fun onEntityDamageByEntity(event: EntityDamageByEntityEvent) {
        if (event.damager is Player && event.entity is Player && cache.contains(event.damager.uniqueId)) {
            val attacker = event.damager as Player
            val victim = event.entity as Player

            if (Random().nextDouble() <= 0.05) { // 5% 几率
                PlayerData.getPlayerTalent(victim)?.removeFirst()
            }
        }
    }

}