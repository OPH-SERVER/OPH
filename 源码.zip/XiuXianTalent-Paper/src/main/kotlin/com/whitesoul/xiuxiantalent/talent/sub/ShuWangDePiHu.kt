package com.whitesoul.xiuxiantalent.talent.sub

import com.whitesoul.xiuxiantalent.instance
import org.bukkit.Bukkit
import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.event.Listener
import org.bukkit.inventory.ItemStack
import org.bukkit.scheduler.BukkitRunnable
import org.bukkit.scheduler.BukkitTask
import java.util.*

object ShuWangDePiHu: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){
        startStoneDropTask()
    }
    private fun startStoneDropTask() {
        object : BukkitRunnable() {
            override fun run() {
                cache.forEach { uuid ->
                    val player = Bukkit.getPlayer(uuid)

                    // 随机给玩家一个石头
                    val stone = ItemStack(Material.entries.random(), 1)
                    player?.inventory?.addItem(stone)
                    player?.sendMessage("§a你获得了一个石头!")
                }
            }
        }.runTaskTimer(instance!!, 3L * 60L * 60L * 20L, 3L * 60L * 60L * 20L)
    }
}