package com.whitesoul.xiuxiantalent.talent.sub

import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.player.PlayerChangedWorldEvent
import org.bukkit.event.player.PlayerItemConsumeEvent
import org.bukkit.event.player.PlayerJoinEvent
import org.bukkit.event.player.PlayerRespawnEvent
import org.bukkit.potion.PotionEffect
import org.bukkit.potion.PotionEffectType
import org.bukkit.scheduler.BukkitTask
import java.util.*

object MenJiangShengTi: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }
    @EventHandler
    fun onPlayerJoin(event: PlayerJoinEvent) {
        if (getPlayer().contains(event.player.uniqueId))

        addEffectsToPlayer(event.player)
    }

    @EventHandler
    fun onPlayerRespawn(event: PlayerRespawnEvent) {
        if (getPlayer().contains(event.player.uniqueId))

        addEffectsToPlayer(event.player)
    }
    @EventHandler
    fun onPlayerJoinWorld(event: PlayerChangedWorldEvent) {
        if (getPlayer().contains(event.player.uniqueId))

        addEffectsToPlayer(event.player)
    }
    @EventHandler
    fun onPlayerItemUse(event: PlayerItemConsumeEvent) {
        if (getPlayer().contains(event.player.uniqueId))

        if (event.item.type == Material.MILK_BUCKET) {
            addEffectsToPlayer(event.player)
        }
    }

    private fun addEffectsToPlayer(player: Player) {
        // 给予玩家永久的缓慢一和抗性提升二效果
        player.addPotionEffect(PotionEffect(PotionEffectType.SLOWNESS, Int.MAX_VALUE, 0, false, false))
        player.addPotionEffect(PotionEffect(PotionEffectType.RESISTANCE, Int.MAX_VALUE, 1, false, false))
    }
}