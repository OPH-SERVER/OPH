package com.whitesoul.xiuxiantalent.talent.sub

import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.player.PlayerItemHeldEvent
import org.bukkit.scheduler.BukkitTask
import java.util.*

object KuangManMoZun: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }
    @EventHandler
    fun onPlayerItemHeld(event: PlayerItemHeldEvent) {
        val player = event.player
        val uuid = player.uniqueId
        if (cache.contains(uuid)) {
            updatePlayerStats(event.player)
        }
    }

    private fun updatePlayerStats(player: Player) {
        val hasArmor = player.inventory.armorContents.any { it != null }
        val health = if (hasArmor) 20 else 20 + 50.0
        val attack = if (hasArmor) 1 else 1 + 10.0

        player.maxHealth = health as Double
        player.health = health
        player.getAttribute(org.bukkit.attribute.Attribute.GENERIC_ATTACK_DAMAGE)?.baseValue = attack as Double
    }
}