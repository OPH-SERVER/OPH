package com.whitesoul.xiuxiantalent.talent.sub

import com.whitesoul.xiuxiantalent.instance
import org.bukkit.Bukkit
import org.bukkit.Material
import org.bukkit.entity.EntityType
import org.bukkit.entity.Player
import org.bukkit.entity.Skeleton
import org.bukkit.entity.WitherSkeleton
import org.bukkit.event.Listener
import org.bukkit.inventory.ItemStack
import org.bukkit.potion.PotionEffect
import org.bukkit.potion.PotionEffectType
import org.bukkit.scheduler.BukkitRunnable
import org.bukkit.scheduler.BukkitTask
import java.util.*

object HeiRouSiLe: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }

    // 注册天赋
    fun register() {
        scheduleWitherSkeletonSummon()
    }

    private fun scheduleWitherSkeletonSummon() {
        object : BukkitRunnable() {
            override fun run() {
                for (uuid in cache) {
                    val player = Bukkit.getPlayer(uuid)
                    if (player != null)
                    summonWitherSkeletons(player)
                }
            }
        }.runTaskTimer(instance!!, 10 * 60.toLong(), 10 * 60.toLong())
    }

    private fun summonWitherSkeletons(player: Player) {
        val location = player.location.add(0.0, 1.0, 0.0)

        repeat(2) {
            val skeleton = location.world.spawnEntity(location, EntityType.WITHER_SKELETON) as WitherSkeleton
            skeleton.equipment.setItemInMainHand(ItemStack(Material.STONE_SWORD))
            skeleton.addPotionEffect(PotionEffect(PotionEffectType.WITHER, Int.MAX_VALUE, 0))
            skeleton.isCustomNameVisible = true
            skeleton.target = player
        }
    }
}