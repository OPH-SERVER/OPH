package com.whitesoul.xiuxiantalent.talent.sub

import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.entity.EntityDamageEvent
import org.bukkit.potion.PotionEffect
import org.bukkit.potion.PotionEffectType
import org.bukkit.scheduler.BukkitTask
import java.util.*

object ZhanJue: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }
    @EventHandler
    fun onPlayerDamage(event: EntityDamageEvent) {
        if (event.entity is Player) {
            val player = event.entity as Player
            if (player.health <= 6.0 && cache.contains(player.uniqueId)) {
                // 玩家血量低于阈值,给予力量二效果
                applyStrengthEffect(player)
            } else {
                // 玩家血量高于阈值,移除力量效果
                removeStrengthEffect(player)
            }
        }
    }

    private fun applyStrengthEffect(player: Player) {
        val strengthEffect = PotionEffect(PotionEffectType.STRENGTH, Int.MAX_VALUE, 2 - 1, false, false)
        player.addPotionEffect(strengthEffect)
    }

    private fun removeStrengthEffect(player: Player) {
        player.removePotionEffect(PotionEffectType.STRENGTH)
    }
}