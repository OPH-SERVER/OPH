package com.whitesoul.xiuxiantalent.talent.sub

import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.player.PlayerItemConsumeEvent
import org.bukkit.potion.PotionEffect
import org.bukkit.potion.PotionEffectType
import org.bukkit.scheduler.BukkitTask
import java.util.*

object LaoBa: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }
    @EventHandler
    fun onPlayerConsumeRottenFlesh(event: PlayerItemConsumeEvent) {
        val player = event.player
        val item = event.item

        if (item.type == Material.ROTTEN_FLESH && cache.contains(player.uniqueId)) {
            event.isCancelled = true // 取消默认的腐肉效果
            addSaturationEffect(player)
        }
    }

    private fun addSaturationEffect(player: Player) {
        val saturationEffect = PotionEffect(PotionEffectType.SATURATION, 20 * 10, 0, false, false) // 10 秒饱和效果
        player.addPotionEffect(saturationEffect)
        player.sendMessage("吃下腐肉后,你感到十分饱腹!")
    }
}