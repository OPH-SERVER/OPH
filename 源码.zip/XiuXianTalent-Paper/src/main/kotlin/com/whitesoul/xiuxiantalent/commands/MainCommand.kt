package com.whitesoul.xiuxiantalent.commands

import com.whitesoul.xiuxiantalent.data.PlayerData
import com.whitesoul.xiuxiantalent.ui.TalentUiManager
import org.bukkit.command.Command
import org.bukkit.command.CommandExecutor
import org.bukkit.command.CommandSender
import org.bukkit.entity.Player


class MainCommand: CommandExecutor {
    override fun onCommand(sender: CommandSender, command: Command, arg: String, args: Array<out String>?): Boolean {
        val player = sender as Player
        PlayerData.reducePlayerCount(player,1)
        TalentUiManager.openTalentUi(player)
        return false
    }
}