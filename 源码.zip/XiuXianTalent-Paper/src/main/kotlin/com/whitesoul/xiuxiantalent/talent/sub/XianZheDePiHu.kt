package com.whitesoul.xiuxiantalent.talent.sub

import com.whitesoul.xiuxiantalent.instance
import org.bukkit.Bukkit
import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.event.Listener
import org.bukkit.inventory.ItemStack
import org.bukkit.scheduler.BukkitRunnable
import org.bukkit.scheduler.BukkitTask
import java.util.*

object XianZheDePiHu: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }

        // 注册天赋
        fun register(){
            startPorkChopTimer()
        }
        private fun startPorkChopTimer() {
            object : BukkitRunnable() {
                override fun run() {
                    for (player in getPlayer()) {
                        addTotemToPlayer(Bukkit.getPlayer(player)!!)
                    }
                }
            }.runTaskTimer(instance!!, 0L, 20 * 60 * 20) // 每 30 分钟执行一次
    }


    private fun addTotemToPlayer(player: Player) {
        val totem = ItemStack(Material.TOTEM_OF_UNDYING, 2)
        player.inventory.addItem(totem)
    }
}