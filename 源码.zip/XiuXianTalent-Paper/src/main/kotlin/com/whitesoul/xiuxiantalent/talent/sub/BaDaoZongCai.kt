package com.whitesoul.xiuxiantalent.talent.sub

import com.whitesoul.xiuxiantalent.instance
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.player.PlayerJoinEvent
import org.bukkit.scheduler.BukkitTask
import java.util.*

object BaDaoZongCai: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }
    // 玩家进入
    @EventHandler
    fun onPlayerEnter(event: PlayerJoinEvent) {
        if (cache.contains(event.player.uniqueId)) {
            if (!event.player.hasPermission("badaozongcai")) {
                grantPermission(event.player)
            }
        }
    }

    private fun grantPermission(player: Player) {
        val attachment = player.addAttachment(instance!!)
        attachment.setPermission("badaozongcai", true)
    }

}