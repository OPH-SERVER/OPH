package com.whitesoul.xiuxiantalent.talent.sub

import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.entity.EntityDamageByEntityEvent
import org.bukkit.scheduler.BukkitTask
import java.util.*

object JianXian: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }
    @EventHandler
    fun onEntityDamageByEntity(event: EntityDamageByEntityEvent) {
        // 检查攻击者是否为玩家
        if (event.damager is Player && getPlayer().contains(event.damager.uniqueId)) {
            val player = event.damager as Player
            // 检查玩家手持的物品是否为剑
            if (player.inventory.itemInMainHand.type.name.contains("SWORD")) {
                // 增加伤害值
                event.damage *= 1.5
            }
        }
    }
}