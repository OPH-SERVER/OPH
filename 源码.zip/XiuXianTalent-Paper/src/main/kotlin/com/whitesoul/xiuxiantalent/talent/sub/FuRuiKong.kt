package com.whitesoul.xiuxiantalent.talent.sub

import com.whitesoul.xiuxiantalent.instance
import org.bukkit.Bukkit
import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.player.PlayerJoinEvent
import org.bukkit.inventory.ItemStack
import org.bukkit.scheduler.BukkitRunnable
import org.bukkit.scheduler.BukkitTask
import java.util.*


object FuRuiKong: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){
        startPorkChopTimer()
    }
    private fun startPorkChopTimer() {
        object : BukkitRunnable() {
            override fun run() {
                for (player in getPlayer()) {
                    givePlayerPorkChop(Bukkit.getPlayer(player)!!)
                }
            }
        }.runTaskTimer(instance!!, 0L, 20 * 60 * 30) // 每 30 分钟执行一次
    }

    private fun givePlayerPorkChop(player: Player) {
        val porkChop = ItemStack(Material.PORKCHOP, 64)
        player.inventory.addItem(porkChop)
    }
}