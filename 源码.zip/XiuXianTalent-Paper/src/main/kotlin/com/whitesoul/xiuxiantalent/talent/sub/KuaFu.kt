package com.whitesoul.xiuxiantalent.talent.sub

import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.player.PlayerMoveEvent
import org.bukkit.potion.PotionEffect
import org.bukkit.potion.PotionEffectType
import org.bukkit.scheduler.BukkitTask
import java.util.*

object KuaFu: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }
    @EventHandler
    fun onPlayerMove(event: PlayerMoveEvent) {
        val player = event.player
        val from = event.from
        val to = event.to
        if (getPlayer().contains(player.uniqueId)) {
            // 检查玩家是否向东方奔跑
            if (from.x < to.x && isEastFacing(player)) {
                // 给予速度 5 效果
                player.addPotionEffect(PotionEffect(PotionEffectType.SPEED, 20, 4, false, false))
            } else {
                // 移除速度效果
                player.removePotionEffect(PotionEffectType.SPEED)
            }
        }
    }

    private fun isEastFacing(player: Player): Boolean {
        val yaw = player.location.yaw
        return yaw in (-90F..90F)
    }
}