package com.whitesoul.xiuxiantalent.talent.sub

import com.whitesoul.xiuxiantalent.instance
import org.bukkit.entity.EntityType
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.player.PlayerJoinEvent
import org.bukkit.scheduler.BukkitRunnable
import org.bukkit.scheduler.BukkitTask
import java.util.*

object Coke:Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }
    @EventHandler
    fun onPlayerJoin(event: PlayerJoinEvent) {
        val uuid = event.player.uniqueId
        if (cache.contains(uuid)) {
            val player = event.player
            val task = object : BukkitRunnable() {
            override fun run() {
                spawnCat(player)
            }
        }.runTaskTimer(instance!!, 0L, 30L * 60L * 20L)
        taskCache[uuid] = task
            }
    }


    private fun spawnCat(player: Player) {
        val location = player.location.add(0.0, 1.0, 0.0)
        player.world.spawnEntity(location, EntityType.CAT)
        }
    }
