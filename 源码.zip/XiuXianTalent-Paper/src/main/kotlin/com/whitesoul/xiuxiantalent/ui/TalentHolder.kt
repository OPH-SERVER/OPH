package com.whitesoul.xiuxiantalent.ui

import org.bukkit.Bukkit
import org.bukkit.event.inventory.InventoryType
import org.bukkit.inventory.Inventory
import org.bukkit.inventory.InventoryHolder

object TalentHolder: InventoryHolder {
    override fun getInventory(): Inventory {
        return Bukkit.createInventory(this, InventoryType.CHEST, "§b§l天赋抽取")
    }
}