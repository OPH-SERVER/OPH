package com.whitesoul.xiuxiantalent.talent

import com.whitesoul.xiuxiantalent.data.PlayerData
import com.whitesoul.xiuxiantalent.talent.sub.*
import org.bukkit.Bukkit
import org.bukkit.entity.Player
import org.bukkit.plugin.Plugin

class TalentManager {
    // 注册事件
    fun registerEvents(plugin: Plugin) {
        // 肥宅圣体
        Bukkit.getPluginManager().registerEvents(FeiZhaiShengTi, plugin)
        // 耐摔王
        Bukkit.getPluginManager().registerEvents(NaiShuaiWang, plugin)
        // 夸父
        Bukkit.getPluginManager().registerEvents(KuaFu, plugin)
        // 门将圣体
        Bukkit.getPluginManager().registerEvents(MenJiangShengTi, plugin)
        // 戴夫
        Bukkit.getPluginManager().registerEvents(DaiFu, plugin)
        // 海贼王
        Bukkit.getPluginManager().registerEvents(HaiZeiWang, plugin)
        // 食神
        Bukkit.getPluginManager().registerEvents(ShiShen, plugin)
        // 剑仙
        Bukkit.getPluginManager().registerEvents(JianXian, plugin)
        // 桃花仙人
        Bukkit.getPluginManager().registerEvents(TaoHuaXianRen, plugin)
        // 霸道总裁
        Bukkit.getPluginManager().registerEvents(BaDaoZongCai, plugin)
        // 原神玩家
        Bukkit.getPluginManager().registerEvents(YuanShenWanJia, plugin)
        // 维欸屁亦
        Bukkit.getPluginManager().registerEvents(WeiAiPiYi, plugin)
        // 失心的樵夫
        Bukkit.getPluginManager().registerEvents(ShiXinDeQiaoFu, plugin)
        // 杜英投手
        Bukkit.getPluginManager().registerEvents(DuYingTouShou, plugin)
        // coke
        Bukkit.getPluginManager().registerEvents(Coke, plugin)
        // 点石成金
        Bukkit.getPluginManager().registerEvents(DianShiChengJin, plugin)
        // Look to the sky
        Bukkit.getPluginManager().registerEvents(LookToTheSky, plugin)
        // 河神
        Bukkit.getPluginManager().registerEvents(HeShen, plugin)
        // 飞段
        Bukkit.getPluginManager().registerEvents(FeiDuan, plugin)
        // 神关羽
        Bukkit.getPluginManager().registerEvents(ShenGuanYu, plugin)
        // 痞老板
        Bukkit.getPluginManager().registerEvents(PiLaoBan, plugin)
        // 黄盖
        Bukkit.getPluginManager().registerEvents(HuangGai, plugin)
        // 孙笑川
        Bukkit.getPluginManager().registerEvents(SunXiaoChuan, plugin)
        // 漩涡鸣人
        Bukkit.getPluginManager().registerEvents(XuanWoMingRen, plugin)
        // 天禄
        Bukkit.getPluginManager().registerEvents(TianLu, plugin)
        // 乱雄
        Bukkit.getPluginManager().registerEvents(LuanXiong, plugin)
        // 屯田
        Bukkit.getPluginManager().registerEvents(TunTian, plugin)
        // 乌突骨
        Bukkit.getPluginManager().registerEvents(WuTuGu, plugin)
        // 坤坤的赠品
        Bukkit.getPluginManager().registerEvents(KunKunDeZengPin, plugin)
        // 老八
        Bukkit.getPluginManager().registerEvents(LaoBa, plugin)
        // 黑手
        Bukkit.getPluginManager().registerEvents(ShenYingGe, plugin)
        // 狂蛮魔尊
        Bukkit.getPluginManager().registerEvents(KuangManMoZun, plugin)
        // 沿江行者
        Bukkit.getPluginManager().registerEvents(YanJiangXingZhe, plugin)
        // 神的一瞥
        Bukkit.getPluginManager().registerEvents(ShenDeYiPie, plugin)
        // 末影
        Bukkit.getPluginManager().registerEvents(MoYing, plugin)
        // 钻石锄头
        Bukkit.getPluginManager().registerEvents(ZuanShiChuTou, plugin)
        // 隐者之紫
        Bukkit.getPluginManager().registerEvents(YinZheZhiZi, plugin)
        // 我不穿裤子
        Bukkit.getPluginManager().registerEvents(WoBuChuanKuZi, plugin)
        // 战绝
        Bukkit.getPluginManager().registerEvents(ZhanJue, plugin)
        // 魅魔
        Bukkit.getPluginManager().registerEvents(MeiMo, plugin)
        // 因为你善
        Bukkit.getPluginManager().registerEvents(YinWeiNiShan, plugin)
        // 已给路打油
        Bukkit.getPluginManager().registerEvents(YiGeiLuDaYou, plugin)
        // 续缘
        Bukkit.getPluginManager().registerEvents(XuYuan, plugin)
        // 高山流水
        Bukkit.getPluginManager().registerEvents(GaoShanLiuShui, plugin)
        // 尼哥
        Bukkit.getPluginManager().registerEvents(NiGe, plugin)
        // 大妖皇真经
        Bukkit.getPluginManager().registerEvents(DaYaoHuangZhenJing, plugin)
        // 鼠王的庇护
        Bukkit.getPluginManager().registerEvents(ShuWangDePiHu, plugin)
        // 白凝冰
        Bukkit.getPluginManager().registerEvents(BaiNingBing, plugin)
        // 业炎
        Bukkit.getPluginManager().registerEvents(YeYan, plugin)
    }

    // 注册天赋
    fun registerTalents() {
        // 鼠王的庇护
        ShuWangDePiHu.register()
        // 肥宅圣体
        FeiZhaiShengTi.register()
        // 白马鬼叔
        BaiMaGuiShu.register()
        // 桃花仙人
        TaoHuaXianRen.register()
        // 福瑞控
        FuRuiKong.register()
        // 战士
        ZhanShi.register()
        // 农场主
        NongChangZhu.register()
        // 迷你世界(低概率)
        MiNiShiJie.register()
        // 飞天蟑螂
        FeiTianZhangLang.register()
        // 幽匿尖啸者
        YouNiJianXiaoZhe.register()
        // 无影无踪
        WuYingWuZong.register()
        // 常清静经
        ChangQingJingJing.register()
        // 乱雄
        LuanXiong.register()
        // 贤者的庇佑
        XianZheDePiHu.register()
        // 黑肉死了
        HeiRouSiLe.register()
        // 伞兵1号卢本伟
        LvBenWei.register()
    }

    // 添加玩家天赋效果
    fun initPlayer(player: Player) {
        // 获取玩家拥有的天赋
        val talents = PlayerData.getPlayerTalent(player)
        println(talents)
        if (talents != null) {
            // 业炎
            if (talents.contains("业炎")) {
                YeYan.addPlayer(player)
            }
            // 白凝冰
            if (talents.contains("白凝冰")) {
                BaiNingBing.addPlayer(player)
            }
            // 鼠王的庇护
            if (talents.contains("鼠王的庇护")) {
                ShuWangDePiHu.addPlayer(player)
            }
            // 大妖皇真经
            if (talents.contains("大妖皇真经")) {
                DaYaoHuangZhenJing.addPlayer(player)
            }
            // 尼哥
            if (talents.contains("尼哥")) {
                NiGe.addPlayer(player)
            }
            // 高山流水
            if (talents.contains("高山流水")) {
                GaoShanLiuShui.addPlayer(player)
            }
            // 续缘
            if (talents.contains("续缘")) {
                XuYuan.addPlayer(player)
            }
            // 已给路打油
            if (talents.contains("已给路打油")) {
                YiGeiLuDaYou.addPlayer(player)
            }
            // 因为你善
            if (talents.contains("因为你善")) {
                YinWeiNiShan.addPlayer(player)
            }
            // 魅魔
            if (talents.contains("魅魔")) {
                MeiMo.addPlayer(player)
            }
            // 战绝
            if (talents.contains("战绝")) {
                ZhanJue.addPlayer(player)
            }
            // 我不穿裤子
            if (talents.contains("我不穿裤子")) {
                WoBuChuanKuZi.addPlayer(player)
            }
            // 隐者之紫
            if (talents.contains("隐者之紫")) {
                YinZheZhiZi.addPlayer(player)
            }
            // 钻石锄头
            if (talents.contains("钻石锄头")) {
                ZuanShiChuTou.addPlayer(player)
                // 末影
                if (talents.contains("末影")) {
                    MoYing.addPlayer(player)
                }
                // 神的一瞥
                if (talents.contains("神的一瞥")) {
                    ShenDeYiPie.addPlayer(player)
                }
                // 岩浆行者
                if (talents.contains("岩浆行者")) {
                    YanJiangXingZhe.addPlayer(player)
                }
                // 狂蛮魔尊
                if (talents.contains("狂蛮魔尊")) {
                    KuangManMoZun.addPlayer(player)
                }
                // 神鹰哥
                if (talents.contains("神鹰哥")) {
                    ShenYingGe.addPlayer(player)
                }
                // 伞兵1号卢本伟
                if (talents.contains("伞兵1号卢本伟")) {
                    LvBenWei.addPlayer(player)
                }
                // 黑肉死了
                if (talents.contains("黑肉死了")) {
                    HeiRouSiLe.addPlayer(player)
                }
                // 老八
                if (talents.contains("老八")) {
                    LaoBa.addPlayer(player)
                }
                // 坤坤的赠品
                if (talents.contains("坤坤的赠品")) {
                    KunKunDeZengPin.addPlayer(player)
                }
                // 贤者的庇佑
                if (talents.contains("贤者的庇佑")) {
                    XianZheDePiHu.addPlayer(player)
                }
                // 乌突骨
                if (talents.contains("乌突骨")) {
                    WuTuGu.addPlayer(player)
                }
                // 屯田
                if (talents.contains("屯田")) {
                    TunTian.addPlayer(player)
                }
                // 乱雄
                if (talents.contains("乱雄")) {
                    LuanXiong.addPlayer(player)
                }
                // 天禄
                if (talents.contains("天禄(极低概率)")) {
                    TianLu.addPlayer(player)
                }
                // 漩涡鸣人
                if (talents.contains("漩涡鸣人(九喇嘛连结)")) {
                    XuanWoMingRen.addPlayer(player)
                }
                // 孙笑川
                if (talents.contains("孙笑川(低概率)")) {
                    SunXiaoChuan.addPlayer(player)
                }
                // 常清静经
                if (talents.contains("常清静经")) {
                    ChangQingJingJing.addPlayer(player)
                }
                // 黄盖
                if (talents.contains("黄盖")) {
                    HuangGai.addPlayer(player)
                }
                // 痞老板
                if (talents.contains("痞老板")) {
                    PiLaoBan.addPlayer(player)
                }
                // 神关羽
                if (talents.contains("神关羽")) {
                    ShenGuanYu.addPlayer(player)
                }
                // 飞段
                if (talents.contains("飞段")) {
                    FeiDuan.addPlayer(player)
                }
                // 河神
                if (talents.contains("河神")) {
                    HeShen.addPlayer(player)
                }
                // Look to the sky
                if (talents.contains("Looktothesky")) {
                    LookToTheSky.addPlayer(player)
                }
                // 点石成金
                if (talents.contains("点石成金")) {
                    DianShiChengJin.addPlayer(player)
                }
                // 无影无踪
                if (talents.contains("无影无踪")) {
                    WuYingWuZong.addPlayer(player)
                }
                // 肥宅圣体
                if (talents.contains("肥宅圣体")) {
                    FeiZhaiShengTi.addPlayer(player)
                }
                // 耐摔王
                if (talents.contains("耐摔王")) {
                    NaiShuaiWang.addPlayer(player)
                }
                // 夸父
                if (talents.contains("夸父")) {
                    KuaFu.addPlayer(player)
                }
                // 门将圣体
                if (talents.contains("门将圣体")) {
                    MenJiangShengTi.addPlayer(player)
                }
                // 白马鬼叔
                if (talents.contains("白马鬼叔?")) {
                    BaiMaGuiShu.addPlayer(player)
                }
                // 戴夫
                if (talents.contains("戴夫")) {
                    DaiFu.addPlayer(player)
                }
                // 海贼王
                if (talents.contains("海贼王")) {
                    HaiZeiWang.addPlayer(player)
                }
                // 食神
                if (talents.contains("食神")) {
                    ShiShen.addPlayer(player)
                }
                // 剑仙
                if (talents.contains("剑仙")) {
                    JianXian.addPlayer(player)
                }
                // 桃花仙人
                if (talents.contains("桃花仙人(低概率)")) {
                    TaoHuaXianRen.addPlayer(player)
                }
                // 霸道总裁
                if (talents.contains("霸道总裁")) {
                    BaDaoZongCai.addPlayer(player)
                }
                // 原神玩家
                if (talents.contains("原神玩家")) {
                    YuanShenWanJia.addPlayer(player)
                }
                // 维欸屁亦
                if (talents.contains("维欸屁亦")) {
                    WeiAiPiYi.addPlayer(player)
                }
                // 失心的樵夫
                if (talents.contains("失心的樵夫")) {
                    ShiXinDeQiaoFu.addPlayer(player)
                }
                // 杜英投手
                if (talents.contains("杜英投手")) {
                    DuYingTouShou.addPlayer(player)
                }
                // 福瑞控
                if (talents.contains("福瑞控")) {
                    FuRuiKong.addPlayer(player)
                }
                // coke
                if (talents.contains("coke")) {
                    Coke.addPlayer(player)
                }
                // 战士
                if (talents.contains("战士(低概率)")) {
                    ZhanShi.addPlayer(player)
                }
                // 农场主
                if (talents.contains("农场主")) {
                    NongChangZhu.addPlayer(player)
                }
                // 迷你世界(低概率)
                if (talents.contains("迷你世界(低概率)")) {
                    MiNiShiJie.addPlayer(player)
                }
                // 幽匿尖啸者(低概率)
                if (talents.contains("幽匿尖啸者(低概率)")) {
                    YouNiJianXiaoZhe.addPlayer(player)
                }
                // TODO: 天生炉鼎
                if (talents.contains("天生炉鼎")) {
                    TianShengLuDing.addPlayer(player)
                }
            }
        }
    }
}