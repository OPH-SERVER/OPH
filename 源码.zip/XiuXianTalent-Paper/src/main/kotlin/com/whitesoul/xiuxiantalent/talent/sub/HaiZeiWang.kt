package com.whitesoul.xiuxiantalent.talent.sub

import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.player.PlayerMoveEvent
import org.bukkit.potion.PotionEffect
import org.bukkit.potion.PotionEffectType
import org.bukkit.scheduler.BukkitTask
import java.util.*

object HaiZeiWang: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }
    @EventHandler
    fun onPlayerMove(event: PlayerMoveEvent) {
        val player = event.player
        // 检查玩家是否在水中
        if (player.isInWater && getPlayer().contains(player.uniqueId)) {
            // 给予玩家凋零效果
            player.addPotionEffect(PotionEffect(PotionEffectType.WITHER, 80, 1, false, false))
        }
    }
}