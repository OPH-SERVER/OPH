package com.whitesoul.xiuxiantalent.talent.sub

import org.bukkit.Location
import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.entity.PlayerDeathEvent
import org.bukkit.scheduler.BukkitTask
import java.util.*

object ShenGuanYu: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }
    @EventHandler
    fun onPlayerDeath(event: PlayerDeathEvent) {
        val player = event.entity
        val location = player.location
        if (cache.contains(player.uniqueId)) {
            println(" y e s")
            // 计算 5x5 范围内的位置
            val minX = location.blockX - 2
            val minZ = location.blockZ - 2
            val maxX = location.blockX + 2
            val maxZ = location.blockZ + 2

            // 生成 10 个铁砧
            repeat(10) {
                val x = Random().nextInt(minX, maxX + 1)
                val z = Random().nextInt(minZ, maxZ + 1)
                val y = location.world.getHighestBlockYAt(x, z) + 10
                val anvilLocation = Location(location.world, x.toDouble(), y.toDouble(), z.toDouble())
                location.world.spawnFallingBlock(anvilLocation, Material.ANVIL.createBlockData())
            }
        }
    }
}