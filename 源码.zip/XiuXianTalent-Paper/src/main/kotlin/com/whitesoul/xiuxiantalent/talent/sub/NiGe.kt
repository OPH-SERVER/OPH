package com.whitesoul.xiuxiantalent.talent.sub

import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.entity.EntityDamageByEntityEvent
import org.bukkit.event.entity.EntityRegainHealthEvent
import org.bukkit.scheduler.BukkitTask
import java.util.*

object NiGe: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }
    @EventHandler
    fun onEntityDamage(event: EntityDamageByEntityEvent) {
        if (event.damager is Player && cache.contains(event.damager.uniqueId)) {
            val player = event.damager as Player
            event.damage *= 1.5 // 提升攻击力
        }
    }

    @EventHandler
    fun onEntityRegainHealth(event: EntityRegainHealthEvent) {
        if (event.entity is Player && cache.contains(event.entity.uniqueId)) {
            val player = event.entity as Player
            event.amount *= 1.5 // 提升血量回复
        }
    }
}