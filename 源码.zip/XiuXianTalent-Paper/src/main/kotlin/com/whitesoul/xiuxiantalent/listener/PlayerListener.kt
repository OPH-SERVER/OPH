package com.whitesoul.xiuxiantalent.listener

import com.whitesoul.xiuxiantalent.data.PlayerData
import com.whitesoul.xiuxiantalent.getPlayerDataFile
import com.whitesoul.xiuxiantalent.instance
import com.whitesoul.xiuxiantalent.talent.TalentManager
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.player.PlayerJoinEvent
import org.bukkit.event.player.PlayerQuitEvent
import java.io.File

class PlayerListener: Listener {
    @EventHandler
    fun onPlayerJoin(e: PlayerJoinEvent) {
        val player = e.player
            getPlayerDataFile().apply {
                // 设置玩家抽取次数
                if (!contains("Data.${player.name}")) {
                    set("Data.${player.name}.count", 11)
                    save(File(instance?.dataFolder, "playerData.yml"))
                    PlayerData.setPlayerCount(player,11)
                } else {
                    val count = getInt("Data.${player.name}.count")
                    PlayerData.setPlayerCount(player,count)
                    PlayerData.addPlayerTalent(player, getStringList("Data.${player.name}.talent"))
                    TalentManager().initPlayer(player)
                }
            }
    }
    @EventHandler
    fun onPlayerQuit(e: PlayerQuitEvent) {
        val player = e.player
        player.clearActivePotionEffects()
        player.maxHealth = 20.0
        player.health = 20.0
        getPlayerDataFile().apply {
            if (contains("Data.${player.name}")) {
                set("Data.${player.name}.count", PlayerData.getPlayerCount(player))
                set("Data.${player.name}.talent",PlayerData.getPlayerTalent(player))
                save(File(instance?.dataFolder, "playerData.yml"))
            }
        }
    }
}