package com.whitesoul.xiuxiantalent.util

import net.kyori.adventure.text.Component
import org.bukkit.ChatColor
import org.bukkit.Material
import org.bukkit.inventory.ItemStack

    // 构建物品
    fun buildItem(type: Material, name: String, lore: List<String>): ItemStack {
        val item = ItemStack(type)
        item.itemMeta = item.itemMeta.apply {
            displayName(Component.text(ChatColor.translateAlternateColorCodes('&',name)))
            lore(lore.map { Component.text(ChatColor.translateAlternateColorCodes('&',it)) })
        }
        return item
    }