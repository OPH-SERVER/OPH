package com.whitesoul.xiuxiantalent.talent.sub

import org.bukkit.entity.LivingEntity
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.entity.EntityDamageByEntityEvent
import org.bukkit.potion.PotionEffect
import org.bukkit.potion.PotionEffectType
import org.bukkit.scheduler.BukkitTask
import java.util.*

object MeiMo: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }
    @EventHandler
    fun onEntityDamageByEntity(event: EntityDamageByEntityEvent) {
        if (event.damager is LivingEntity && event.entity is LivingEntity && cache.contains(event.damager.uniqueId)) {
            val damager = event.damager as LivingEntity
            val victim = event.entity as LivingEntity

            // 给予受害者力量和生命回复效果
            applyEffectsToVictim(victim)

            // 给予攻击者虚弱效果
            applyWeaknessToAttacker(damager)
        }
    }

    private fun applyEffectsToVictim(victim: LivingEntity) {
        val strengthEffect = PotionEffect(PotionEffectType.STRENGTH, Int.MAX_VALUE, 2 - 1, false, false)
        val regenerationEffect = PotionEffect(PotionEffectType.REGENERATION, Int.MAX_VALUE, 1 - 1, false, false)
        victim.addPotionEffect(strengthEffect)
        victim.addPotionEffect(regenerationEffect)
    }

    private fun applyWeaknessToAttacker(attacker: LivingEntity) {
        val weaknessEffect = PotionEffect(PotionEffectType.WEAKNESS, Int.MAX_VALUE, 1 - 1, false, false)
        attacker.addPotionEffect(weaknessEffect)
    }
}