package com.whitesoul.xiuxiantalent.talent.sub

import org.bukkit.Location
import org.bukkit.Material
import org.bukkit.entity.LivingEntity
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.entity.EntityDamageByEntityEvent
import org.bukkit.potion.PotionEffect
import org.bukkit.potion.PotionEffectType
import org.bukkit.scheduler.BukkitTask
import java.util.*

object YeYan: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }
    @EventHandler
    fun onEntityDamage(event: EntityDamageByEntityEvent) {
        if (event.entity is Player && event.damager is LivingEntity && cache.contains(event.entity.uniqueId)) {
            val player = event.entity as Player
            val attacker = event.damager as LivingEntity

            // 在玩家脚下生成火焰
            generateFire(player.location)

            // 给予玩家火焰保护
            applyFireProtection(player)

        }
    }

    private fun generateFire(location: Location) {
        // 在3×3范围内生成火焰
        for (x in -3..3) {
            for (y in -1..1) {
                for (z in -3..3) {
                    val blockLoc = location.clone().add(x.toDouble(), y.toDouble(), z.toDouble())
                    blockLoc.block.type = Material.FIRE
                }
            }
        }
    }

    private fun applyFireProtection(player: Player) {
        // 给予玩家火焰保护效果
        player.addPotionEffect(
            PotionEffect(
                PotionEffectType.FIRE_RESISTANCE,
                5 * 20, // 持续时间(ticks)
                0
            )
        )
    }
}