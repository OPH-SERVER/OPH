package com.whitesoul.xiuxiantalent.talent.sub

import com.whitesoul.xiuxiantalent.instance
import org.bukkit.Bukkit
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.player.PlayerJoinEvent
import org.bukkit.potion.PotionEffect
import org.bukkit.potion.PotionEffectType
import org.bukkit.scheduler.BukkitTask
import java.util.*

object TaoHuaXianRen: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){
        Bukkit.getScheduler().runTaskTimer(instance!!, Runnable {
            cache.forEach { uuid ->
                val player = Bukkit.getPlayer(uuid)
                if (player != null) {
                    applyEffects(player)
                }
        }
    },20L,20L)
    }

    @EventHandler
    fun onPlayerJoin(event: PlayerJoinEvent) {
        cache.forEach { uuid ->
            val player = Bukkit.getPlayer(uuid)
            if (player != null) {
                applyEffects(player)
            }
            applyEffects(event.player)
        }
    }

    private fun applyEffects(player: Player) {
        // 永久加50点血量
        player.maxHealth = player.maxHealth + 50
        player.health = player.maxHealth

        // 永久抗性提升二效果
        player.addPotionEffect(PotionEffect(PotionEffectType.RESISTANCE, Int.MAX_VALUE, 1, true, false))

        // 永久饱和效果
        player.addPotionEffect(PotionEffect(PotionEffectType.SATURATION, Int.MAX_VALUE, 0, true, false))
    }
}