package com.whitesoul.xiuxiantalent.talent.sub

import com.whitesoul.xiuxiantalent.instance
import org.bukkit.entity.LivingEntity
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.entity.EntityDamageByEntityEvent
import org.bukkit.scheduler.BukkitRunnable
import org.bukkit.scheduler.BukkitTask
import org.bukkit.util.Vector
import java.util.*

object ShenYingGe: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }

    // 注册天赋
    fun register() {

    }

    @EventHandler
    fun onEntityDamage(event: EntityDamageByEntityEvent) {
        val damager = event.damager
        val victim = event.entity

        if (victim is LivingEntity && damager is LivingEntity && cache.contains(damager.uniqueId)) {
            launchVictimIntoAir(victim)
        }
    }

    private fun launchVictimIntoAir(victim: LivingEntity) {
        val launchForce = 2.0f // 可以调整这个值来控制生物被弹起的高度
        val launchVector = victim.location.direction.setY(launchForce)
        victim.velocity = launchVector

        // 在 1 秒后改变生物的速度方向,使其悬浮在空中
        object : BukkitRunnable() {
            override fun run() {
                val hoverVector = Vector(0.0, 0.0, 0.0)
                victim.velocity = hoverVector
            }
        }.runTaskLater(instance!!, 20L)
    }
}