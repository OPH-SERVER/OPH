package com.whitesoul.xiuxiantalent.talent.sub

import com.destroystokyo.paper.event.player.PlayerArmorChangeEvent
import org.bukkit.Material
import org.bukkit.enchantments.Enchantment
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.entity.EntityDamageByEntityEvent
import org.bukkit.inventory.ItemStack
import org.bukkit.scheduler.BukkitTask
import java.util.*

object YinZheZhiZi: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }
    @EventHandler
    fun onPlayerEquipArmor(event: PlayerArmorChangeEvent) {
        val player = event.player
        val equippedItem = event.newItem

        if (isArmor(equippedItem.type) && cache.contains(player.uniqueId)) {
            applyThornsEnchant(player, equippedItem)
        } else {
            removeThornsEnchant(player, equippedItem)
        }
    }


    private fun applyThornsEnchant(player: Player, item: ItemStack) {
        item.addUnsafeEnchantment(Enchantment.THORNS, 1)
        player.sendMessage("§a你获得了荆棘附魔!")
    }

    private fun removeThornsEnchant(player: Player, item: ItemStack) {
        item.removeEnchantment(Enchantment.THORNS)
        player.sendMessage("§c你失去了荆棘附魔。")
    }

    private fun isArmor(material: Material): Boolean {
        return material in listOf(
            Material.LEATHER_HELMET, Material.LEATHER_CHESTPLATE, Material.LEATHER_LEGGINGS, Material.LEATHER_BOOTS,
            Material.IRON_HELMET, Material.IRON_CHESTPLATE, Material.IRON_LEGGINGS, Material.IRON_BOOTS,
            Material.GOLDEN_HELMET, Material.GOLDEN_CHESTPLATE, Material.GOLDEN_LEGGINGS, Material.GOLDEN_BOOTS,
            Material.DIAMOND_HELMET, Material.DIAMOND_CHESTPLATE, Material.DIAMOND_LEGGINGS, Material.DIAMOND_BOOTS
        )
    }
}