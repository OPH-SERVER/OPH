package com.whitesoul.xiuxiantalent.talent.sub

import org.bukkit.Location
import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.entity.EntityDamageEvent
import org.bukkit.event.player.PlayerMoveEvent
import org.bukkit.potion.PotionEffect
import org.bukkit.potion.PotionEffectType
import org.bukkit.scheduler.BukkitTask
import java.util.*

object MoYing: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }
    @EventHandler
    fun onPlayerDamage(event: EntityDamageEvent) {
        if (event.entity is Player) {
            val player = event.entity as Player
            if (player.health - event.finalDamage <= 1.0 && cache.contains(player.uniqueId)) {
                teleportPlayer(player)
            }
        }
    }

    @EventHandler
    fun onPlayerMove(event: PlayerMoveEvent) {
        val player = event.player
        if (player.location.block.type == Material.WATER && cache.contains(player.uniqueId)) {
            applyWitherEffect(player)
        }
    }

    private fun teleportPlayer(player: Player) {
        val world = player.world
        val x = Random().nextDouble()
        val y = Random().nextDouble()
        val z = Random().nextDouble()
        val location = Location(world, x, y, z)
        player.teleport(location)
    }

    private fun applyWitherEffect(player: Player) {
        player.addPotionEffect(PotionEffect(PotionEffectType.WITHER, 20 * 5, 1, true, false)) // 5秒的凋零效果
    }
}