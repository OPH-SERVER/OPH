package com.whitesoul.xiuxiantalent.talent.sub

import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.entity.EntityDamageEvent
import org.bukkit.scheduler.BukkitTask
import java.util.*

object NaiShuaiWang: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    @EventHandler
    fun onEntityDamage(event: EntityDamageEvent) {
        if (getPlayer().contains(event.entity.uniqueId)) {
            if (event.cause == EntityDamageEvent.DamageCause.FALL) {
                // 减少50%的衰落伤害
                event.damage *= 0.5
            }
        }
    }
}