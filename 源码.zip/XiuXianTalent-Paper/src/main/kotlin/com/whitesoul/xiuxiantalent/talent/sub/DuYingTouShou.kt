package com.whitesoul.xiuxiantalent.talent.sub

import org.bukkit.entity.EntityType
import org.bukkit.entity.LivingEntity
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.entity.EntityDamageByEntityEvent
import org.bukkit.scheduler.BukkitTask
import java.util.*
import kotlin.collections.HashMap

object DuYingTouShou: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }
    @EventHandler
    fun onEntityDamage(event: EntityDamageByEntityEvent) {
        if (event.damager is LivingEntity && event.entity is LivingEntity) {
            val damager = event.damager as LivingEntity
            val victim = event.entity as LivingEntity
            if (cache.contains(damager.uniqueId)) {
                if (damager.type == EntityType.ZOMBIE) {
                    victim.health = 0.0 // 被僵尸秒杀
                }
                if (victim.health / victim.maxHealth <= 0.4 && Random().nextInt(100) < 5) { // 血量低于40%且5%概率
                    victim.health = 0.0 // 秒杀怪物
                }
            }
        }
    }
}