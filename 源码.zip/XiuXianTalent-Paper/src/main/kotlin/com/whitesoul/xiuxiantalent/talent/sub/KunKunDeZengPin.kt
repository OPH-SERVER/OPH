package com.whitesoul.xiuxiantalent.talent.sub

import org.bukkit.Material
import org.bukkit.entity.Chicken
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.entity.EntityDeathEvent
import org.bukkit.inventory.ItemStack
import org.bukkit.scheduler.BukkitTask
import java.util.*

object KunKunDeZengPin: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }

    // 注册天赋
    fun register() {

    }

    @EventHandler
    fun onChickenDeath(event: EntityDeathEvent) {
        if (event.entity is Chicken && cache.contains(event.entity.uniqueId)) {
            event.drops.clear()
            val type = Material.entries.random()
            if (type.isItem) {
                event.drops.add(ItemStack(type))
            }
        }
    }
}
