package com.whitesoul.xiuxiantalent.talent.sub

import org.bukkit.entity.LivingEntity
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.player.PlayerMoveEvent
import org.bukkit.potion.PotionEffect
import org.bukkit.potion.PotionEffectType
import org.bukkit.scheduler.BukkitTask
import java.util.*

object YuanShenWanJia: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }
    @EventHandler
    fun onPlayerMove(event: PlayerMoveEvent) {
        if (cache.contains(event.player.uniqueId)) {
            applyEffects(event.player)
        }
    }

    private fun applyEffects(player: Player) {
        val location = player.location
        val radius = 2.5 // 半径为 5
        val entities = player.world.getNearbyEntities(location, radius, radius, radius).filterIsInstance<LivingEntity>()
        for (entity in entities) {
            if (entity != player) {
                entity.addPotionEffect(PotionEffect(PotionEffectType.SLOWNESS, 20, 1, true, false))
                entity.addPotionEffect(PotionEffect(PotionEffectType.BLINDNESS, 20, 1, true, false))
            }
        }
    }
}