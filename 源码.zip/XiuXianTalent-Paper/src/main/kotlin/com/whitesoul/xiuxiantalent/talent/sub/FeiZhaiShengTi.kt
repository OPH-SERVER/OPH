package com.whitesoul.xiuxiantalent.talent.sub

import com.whitesoul.xiuxiantalent.XiuXianTalent
import com.whitesoul.xiuxiantalent.instance
import com.whitesoul.xiuxiantalent.util.buildItem
import org.bukkit.Bukkit
import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.player.PlayerMoveEvent
import org.bukkit.inventory.ItemStack
import org.bukkit.scheduler.BukkitTask
import java.util.HashMap
import java.util.UUID

object FeiZhaiShengTi: Listener {

    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }

    // 注册
    fun register() {
        for (uuid in cache) {
            val player = Bukkit.getPlayer(uuid)
            Bukkit.getScheduler().runTaskLater(instance!!, Runnable {
                if (player != null && taskCache[uuid] == null) {
                    taskCache[uuid] = Bukkit.getScheduler().runTaskLater(instance!!, Runnable {
                        player.inventory.addItem(ItemStack(Material.COOKED_CHICKEN))
                    }, 20 * 50L)
                }
            }, 20L)
        }
        // 是否动
        @EventHandler
        fun onPlayerMove(e: PlayerMoveEvent) {
            if (getPlayer().contains(e.player.uniqueId)) {
                taskCache[e.player.uniqueId]?.cancel()
            }
        }
    }
}