package com.whitesoul.xiuxiantalent.talent.sub

import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.block.BlockBreakEvent
import org.bukkit.inventory.ItemStack
import org.bukkit.scheduler.BukkitTask
import java.util.*

object DianShiChengJin: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {

        return cache
    }
    // 注册天赋
    fun register(){

    }
    @EventHandler
    fun onBlockBreak(event: BlockBreakEvent) {
        val player = event.player
        val block = event.block
        if (cache.contains(player.uniqueId)) {
            if (block.type == Material.STONE) {
                givePlayerGold(player)
           }
        }
    }
    private fun givePlayerGold(player: Player) {
        val goldItem = ItemStack(Material.GOLD_NUGGET, 1)
        player.inventory.addItem(goldItem)
        player.sendMessage("你获得了一个金粒!")
    }
}