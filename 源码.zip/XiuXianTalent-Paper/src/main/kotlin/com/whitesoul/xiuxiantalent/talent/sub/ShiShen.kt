package com.whitesoul.xiuxiantalent.talent.sub

import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.entity.FoodLevelChangeEvent
import org.bukkit.scheduler.BukkitTask
import java.util.*

object ShiShen: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }
    @EventHandler
    fun onFoodLevelChange(event: FoodLevelChangeEvent) {
        // 检查事件的触发者是否为玩家
        if (event.entity is Player && getPlayer().contains(event.entity.uniqueId)) {
            val player = event.entity as Player
            // 获取玩家当前的饱食度
            val currentFoodLevel = player.foodLevel
            // 将玩家的新饱食度设置为当前值的2倍
            event.foodLevel = currentFoodLevel * 2
        }
    }
}