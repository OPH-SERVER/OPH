package com.whitesoul.xiuxiantalent.talent.sub

import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.player.PlayerItemHeldEvent
import org.bukkit.potion.PotionEffect
import org.bukkit.potion.PotionEffectType
import org.bukkit.scheduler.BukkitTask
import java.util.*

object ZuanShiChuTou: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }
    @EventHandler
    fun onPlayerItemHeld(event: PlayerItemHeldEvent) {
        val player = event.player
        val heldItem = player.inventory.getItem(event.newSlot)

        if (heldItem?.type == Material.DIAMOND_HOE && cache.contains(player.uniqueId)) {
            applyStrengthEffect(player)
        } else {
            removeStrengthEffect(player)
        }
    }

    private fun applyStrengthEffect(player: Player) {
        player.addPotionEffect(PotionEffect(PotionEffectType.STRENGTH, 20 * 10, 1, true, false)) // 10秒的力量2效果
        player.sendMessage("§a你获得了力量2效果!")
    }

    private fun removeStrengthEffect(player: Player) {
        player.removePotionEffect(PotionEffectType.STRENGTH)
        player.sendMessage("§c你失去了力量2效果。")
    }
}