package com.whitesoul.xiuxiantalent.talent.sub

import com.whitesoul.xiuxiantalent.instance
import org.bukkit.Bukkit
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.player.PlayerJoinEvent
import org.bukkit.potion.PotionEffect
import org.bukkit.potion.PotionEffectType
import org.bukkit.scheduler.BukkitTask
import java.util.*

object WeiAiPiYi: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()
    private val playerKickTimers = HashMap<Player, Long>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){
        Bukkit.getServer().scheduler.runTaskTimer(instance!!, this::checkPlayerKick, 0L, 20L * 60 * 30) // 每30分钟检查一次
    }
    @EventHandler
    fun onPlayerJoin(event: PlayerJoinEvent) {
        val player = event.player
        if (cache.contains(player.uniqueId)) {
            playerKickTimers[player] = System.currentTimeMillis()
            givePlayerEffects(player)
        }
    }

    private fun givePlayerEffects(player: Player) {
        player.addPotionEffect(PotionEffect(PotionEffectType.SPEED, Int.MAX_VALUE, 1, true, false))
        player.allowFlight = true
        player.flySpeed = 0.5f
        player.walkSpeed = 0.5f
    }
    private fun checkPlayerKick() {
        for ((player, joinTime) in playerKickTimers.toMap()) {
            if (System.currentTimeMillis() - joinTime >= 1000 * 60 * 30) { // 30分钟
                player.kickPlayer("你已被服务器踢出")
                playerKickTimers.remove(player)
            }
        }
    }
}