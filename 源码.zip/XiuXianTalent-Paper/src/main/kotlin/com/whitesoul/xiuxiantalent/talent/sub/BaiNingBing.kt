package com.whitesoul.xiuxiantalent.talent.sub

import org.bukkit.entity.LivingEntity
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.entity.EntityDamageByEntityEvent
import org.bukkit.scheduler.BukkitTask
import java.util.*

object BaiNingBing: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }
    @EventHandler
    fun onEntityDamage(event: EntityDamageByEntityEvent) {
        if (event.damager is Player && event.entity is LivingEntity) {
            val player = event.damager as Player
            val target = event.entity as LivingEntity

            // 检查是否从背面攻击
            if (isAttackingFromBehind(player, target)) {
                // 有30%概率一击秒杀
                if (Random().nextDouble() < 0.3 && cache.contains(player.uniqueId)) {
                    target.health = 0.0
                    player.sendMessage("§a你成功发动了背后偷袭,一击秒杀了敌人!")
                } else {
                    player.sendMessage("§e你从背后偷袭了敌人,但没有造成致命伤害。")
                }
            }
        }
    }

    private fun isAttackingFromBehind(player: Player, target: LivingEntity): Boolean {
        val playerLocation = player.location
        val targetLocation = target.location

        // 计算玩家和目标之间的夹角
        val angle = playerLocation.direction.angle(targetLocation.direction)

        // 如果夹角大于90度,则视为从背后攻击
        return angle > Math.PI / 2
    }
}