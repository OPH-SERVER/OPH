package com.whitesoul.xiuxiantalent.talent.sub

import org.bukkit.Material
import org.bukkit.entity.LivingEntity
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.entity.EntityDamageByEntityEvent
import org.bukkit.event.entity.EntityDamageEvent
import org.bukkit.scheduler.BukkitTask
import java.util.*

object LookToTheSky: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }
    @EventHandler
    fun onEntityDamageByEntity(event: EntityDamageByEntityEvent) {
        if (event.damager is Player) {
            val player = event.damager as Player
            val weapon = player.inventory.itemInMainHand
            if (cache.contains(event.entity.uniqueId)) {
                // 检查武器类型并翻倍伤害
                when (weapon.type) {
                    Material.TRIDENT,
                    Material.BOW,
                    Material.CROSSBOW,
                    Material.IRON_SWORD,
                    Material.DIAMOND_SWORD,
                    Material.NETHERITE_SWORD,
                    Material.WOODEN_SWORD,
                    Material.STONE_SWORD,
                    Material.GOLDEN_SWORD,
                    Material.MACE -> event.damage *= 2.0
                    else -> {}
                }
            }
                event.damage *= 1.8
            }
        }
    @EventHandler
    fun onEntityDamage(event: EntityDamageEvent) {
        if (event.entity is LivingEntity) {
            if (cache.contains(event.entity.uniqueId)) {
                // 翻倍受到的伤害
                event.damage *= 2.0
            }
        }
    }
}