package com.whitesoul.xiuxiantalent.talent.sub

import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.entity.EntityDamageByEntityEvent
import org.bukkit.potion.PotionEffect
import org.bukkit.potion.PotionEffectType
import org.bukkit.scheduler.BukkitTask
import java.util.*

object LuanXiong: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }
    @EventHandler
    fun onEntityDamageByEntity(event: EntityDamageByEntityEvent) {
        if (event.damager is Player && event.entity is Player && cache.contains(event.damager.uniqueId)) {
            val attacker = event.damager as Player
            val victim = event.entity as Player

            weakenVictim(victim)
        }
    }

    private fun weakenVictim(player: Player) {
        player.addPotionEffect(PotionEffect(PotionEffectType.WEAKNESS, 10 * 20, 0)) // 10 秒虚弱
        player.sendMessage("你被敌人的攻击削弱了!")
    }
}