package com.whitesoul.xiuxiantalent.ui

import com.whitesoul.xiuxiantalent.data.PlayerData
import org.bukkit.ChatColor
import org.bukkit.Sound
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.inventory.InventoryClickEvent
import org.bukkit.event.inventory.InventoryOpenEvent

class TalentUiListener: Listener {
    @EventHandler
    fun onClickInv(e: InventoryClickEvent) {
        if (e.clickedInventory?.holder != TalentHolder) return
        val player  = e.whoClicked as Player
            e.isCancelled = true
        if (e.slot == 21) {
            player.playSound(player.location,Sound.BLOCK_BONE_BLOCK_BREAK,1F,1F)
            PlayerData.reducePlayerCount(player, 1)

            if (PlayerData.getPlayerCount(player)!! <= 0) {
                player.sendMessage("&e你选择了 ${e.inventory.getItem(12)?.itemMeta?.getDisplayName()} &b| ${e.inventory.getItem(13)?.itemMeta?.getDisplayName()} &b| ${e.inventory.getItem(14)?.itemMeta?.getDisplayName()} &e作为你的天赋!".replace("&","§"))
                player.playSound(player.location,Sound.ENTITY_EXPERIENCE_ORB_PICKUP,1F,2F)
                player.closeInventory()
                PlayerData.addPlayerTalent(player, arrayListOf(ChatColor.stripColor(e.inventory.getItem(12)?.itemMeta?.getDisplayName())!!,ChatColor.stripColor(e.inventory.getItem(13)?.itemMeta?.getDisplayName())!!,ChatColor.stripColor(e.inventory.getItem(14)?.itemMeta?.getDisplayName())!!))
            } else {
                TalentUiManager.openTalentUi(player)
            }
        }
        if (e.slot == 23) {
            player.sendMessage("&e你选择了 ${e.inventory.getItem(12)?.itemMeta?.getDisplayName()} &b| ${e.inventory.getItem(13)?.itemMeta?.getDisplayName()} &b| ${e.inventory.getItem(14)?.itemMeta?.getDisplayName()} &e作为你的天赋!".replace("&","§"))
            player.playSound(player.location,Sound.ENTITY_EXPERIENCE_ORB_PICKUP,1F,2F)
            player.closeInventory()
            PlayerData.addPlayerTalent(player, arrayListOf(ChatColor.stripColor(e.inventory.getItem(12)?.itemMeta?.getDisplayName())!!,ChatColor.stripColor(e.inventory.getItem(13)?.itemMeta?.getDisplayName())!!,ChatColor.stripColor(e.inventory.getItem(14)?.itemMeta?.getDisplayName())!!))
        }
    }
    @EventHandler
    fun onOpenInv(e: InventoryOpenEvent) {
        if (e.inventory.holder != TalentHolder) return
        TalentUiManager.randomTalent(e.inventory)
    }
}