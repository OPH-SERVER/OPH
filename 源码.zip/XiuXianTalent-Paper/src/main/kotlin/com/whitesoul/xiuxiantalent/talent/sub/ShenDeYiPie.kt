package com.whitesoul.xiuxiantalent.talent.sub

import org.bukkit.Bukkit
import org.bukkit.attribute.Attribute
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.entity.EntityDamageEvent
import org.bukkit.potion.PotionEffect
import org.bukkit.potion.PotionEffectType
import org.bukkit.scheduler.BukkitTask
import java.util.*

object ShenDeYiPie: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }
    @EventHandler
    fun onPlayerDamage(event: EntityDamageEvent) {
        if (event.entity is Player && (event.entity as Player).health >= 2 && cache.contains(event.entity.uniqueId)) {
            val player = event.entity as Player
            if (Random().nextDouble() <= 0.02) { // 2%的概率
                healAndBuff(player)
            }
        }
    }

    private fun healAndBuff(player: Player) {
        player.health = player.getAttribute(Attribute.GENERIC_MAX_HEALTH)!!.value
        player.addPotionEffect(PotionEffect(PotionEffectType.STRENGTH, 20 * 30, 19, true, false)) // 20级力量,持续30秒
    }
}