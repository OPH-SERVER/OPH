package com.whitesoul.xiuxiantalent.talent.sub

import org.bukkit.entity.*
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.entity.EntityDamageByEntityEvent
import org.bukkit.potion.PotionEffect
import org.bukkit.potion.PotionEffectType
import org.bukkit.scheduler.BukkitTask
import java.util.*

object YinWeiNiShan: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }
    @EventHandler
    fun onEntityDamageByEntity(event: EntityDamageByEntityEvent) {
        if (event.damager is Player && event.entity is LivingEntity && cache.contains(event.damager.uniqueId)) {
            val player = event.damager as Player
            val victim = event.entity as LivingEntity

            // 检查被攻击的生物是否为牛、羊、猪或鸡
            if (isPassiveEntity(victim)) {
                // 减少50%的伤害
                event.damage *= 0.5

                // 给予玩家一个负面效果,例如:
                player.addPotionEffect(PotionEffect(PotionEffectType.WEAKNESS, 60 * 20, 1)) // 饥饿效果,持续1分钟

                // 向玩家发送一条消息
            }
        }
    }

    private fun isPassiveEntity(entity: LivingEntity): Boolean {
        return entity is Cow || entity is Sheep || entity is Pig || entity is Chicken
    }
}