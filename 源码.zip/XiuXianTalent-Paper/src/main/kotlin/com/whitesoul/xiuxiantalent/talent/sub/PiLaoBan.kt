package com.whitesoul.xiuxiantalent.talent.sub

import com.whitesoul.xiuxiantalent.instance
import org.bukkit.Bukkit
import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.player.PlayerJoinEvent
import org.bukkit.inventory.ItemStack
import org.bukkit.scheduler.BukkitRunnable
import org.bukkit.scheduler.BukkitTask
import java.util.*

object PiLaoBan:Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }

    // 注册天赋
    fun register() {

    }

    @EventHandler
    fun onPlayerJoin(event: PlayerJoinEvent) {
        val player = event.player
        if (cache.contains(player.uniqueId)) {
            reduceMaxHealth(player)
            taskCache[player.uniqueId] = Bukkit.getScheduler().runTaskTimer(instance!!, Runnable {
                giveIronBlocks(player)
            }, 20L * (60L*30L), 20L * (60L*30L) )
        }
    }

    private fun reduceMaxHealth(player: Player) {
        val originalMaxHealth = player.maxHealth
        player.maxHealth = originalMaxHealth * 0.9 // 减少 10%
    }

    private fun giveIronBlocks(player: Player) {
        val ironBlocks = ItemStack(Material.IRON_BLOCK, 64)
        player.inventory.addItem(ironBlocks)
    }
}