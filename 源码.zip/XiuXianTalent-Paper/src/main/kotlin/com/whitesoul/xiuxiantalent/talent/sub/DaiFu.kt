package com.whitesoul.xiuxiantalent.talent.sub

import org.bukkit.entity.EntityType
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.entity.EntityDamageByEntityEvent
import org.bukkit.scheduler.BukkitTask
import java.util.*

object DaiFu:Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }
    @EventHandler
    fun onZombieDamage(event: EntityDamageByEntityEvent) {
        if (getPlayer().contains(event.entity.uniqueId)) {

            // 检查攻击者是否为僵尸
            if (event.damager.type == EntityType.ZOMBIE) {
                // 检查受害者是否为玩家
                if (event.entity is Player) {
                    val player = event.entity as Player
                    // 如果玩家的生命值大于0,立即设置为0
                    if (player.health > 0) {
                        player.health = 0.0
                    }
                }
            }
        }
    }
}