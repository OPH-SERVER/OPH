package com.whitesoul.xiuxiantalent.talent.sub

import com.whitesoul.xiuxiantalent.instance
import org.bukkit.Bukkit
import org.bukkit.entity.Entity
import org.bukkit.entity.Player
import org.bukkit.event.Listener
import org.bukkit.potion.PotionEffect
import org.bukkit.potion.PotionEffectType
import org.bukkit.scheduler.BukkitTask
import java.util.*

object WuYingWuZong: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){
        Bukkit.getScheduler().runTaskTimer(instance!!, Runnable {
            for (uuid in getPlayer()) {
                val player = Bukkit.getPlayer(uuid)
                if (hasNoEntitiesNearby(player!!)) {
                    givePlayerInvisibility(player)
                } else {
                    removePlayerInvisibility(player)
                }
            }
        },20L,20L)
    }

    private fun hasNoEntitiesNearby(player: Player): Boolean {
        val entities = player.world.getNearbyEntities(player.location, 5.toDouble(), 5.toDouble(), 5.toDouble())
        return entities.none { it is Player || it is Entity }
    }

    private fun givePlayerInvisibility(player: Player) {
        player.addPotionEffect(PotionEffect(PotionEffectType.INVISIBILITY, Int.MAX_VALUE, 0, false, false))
    }

    private fun removePlayerInvisibility(player: Player) {
        player.removePotionEffect(PotionEffectType.INVISIBILITY)
    }
}