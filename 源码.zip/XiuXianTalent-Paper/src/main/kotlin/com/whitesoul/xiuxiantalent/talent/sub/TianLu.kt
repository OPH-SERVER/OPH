package com.whitesoul.xiuxiantalent.talent.sub

import org.bukkit.Location
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.entity.PlayerDeathEvent
import org.bukkit.scheduler.BukkitTask
import java.util.*

object TianLu:Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }
    @EventHandler
    fun onPlayerDeath(event: PlayerDeathEvent) {
        val player = event.entity
        val deathLocation = player.location
        respawnPlayerAtLocation(player, deathLocation)
    }

    private fun respawnPlayerAtLocation(player: Player, location: Location) {
        player.health = player.maxHealth // 恢复满生命
        player.teleport(location) // 将玩家传送回死亡地点
        player.sendMessage("你死亡后原地重生了!")
    }
}