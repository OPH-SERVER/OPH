package com.whitesoul.xiuxiantalent.talent.sub

import com.whitesoul.xiuxiantalent.instance
import org.bukkit.Bukkit
import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.inventory.ItemStack
import org.bukkit.potion.PotionEffect
import org.bukkit.potion.PotionEffectType
import org.bukkit.scheduler.BukkitTask
import java.util.*

object FeiTianZhangLang {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){
        Bukkit.getScheduler().runTaskTimer(instance!!, Runnable {
            for(uuid in getPlayer()) {
                val player = Bukkit.getPlayer(uuid)
                if (player != null) {
                    player.inventory.addItem(ItemStack(Material.ELYTRA))
                    player.inventory.addItem(ItemStack(Material.FIREWORK_ROCKET))
                }
            }
        },20L,20L * (60L * 60L))
    }
}