package com.whitesoul.xiuxiantalent.talent.sub

import com.whitesoul.xiuxiantalent.util.buildItem
import org.bukkit.Bukkit
import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.block.BlockBreakEvent
import org.bukkit.inventory.ItemStack
import org.bukkit.scheduler.BukkitTask
import java.util.*

object TunTian: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }
    @EventHandler
    fun onBlockBreak(event: BlockBreakEvent) {
        val player = event.player
        val block = event.block

        if (block.type == Material.WHEAT && block.state.type == Material.WHEAT && cache.contains(player.uniqueId)) {
            giveGoldToPlayer(player)
        }
    }

    private fun giveGoldToPlayer(player: Player) {
        val item = buildItem(Material.PAPER,"&c九阶灵石", arrayListOf(""))
        player.inventory.addItem(item)
        player.sendMessage("你收获了小麦,获得了一个金锭!")
    }
}