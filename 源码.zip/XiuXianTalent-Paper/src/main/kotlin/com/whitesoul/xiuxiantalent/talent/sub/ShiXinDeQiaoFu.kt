package com.whitesoul.xiuxiantalent.talent.sub

import org.bukkit.Material
import org.bukkit.entity.LivingEntity
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.entity.EntityDamageByEntityEvent
import org.bukkit.potion.PotionEffect
import org.bukkit.potion.PotionEffectType
import org.bukkit.scheduler.BukkitTask
import java.util.*

object ShiXinDeQiaoFu: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }
    @EventHandler
    fun onEntityDamage(event: EntityDamageByEntityEvent) {
        if (event.damager is LivingEntity && event.entity is LivingEntity) {
            val damager = event.damager as LivingEntity
            val victim = event.entity as LivingEntity
            if (cache.contains(damager.uniqueId)) {
                if (damager.equipment?.itemInMainHand?.type == Material.MACE) {
                    if (victim.health - event.damage <= 0) { // 目标已死亡
                        givePlayerEffect(damager)
                    }
                }
            }
        }
    }

    private fun givePlayerEffect(player: LivingEntity) {
        player.addPotionEffect(PotionEffect(PotionEffectType.STRENGTH, 20 * 60, 4, true, false)) // 力量 5 持续 1 分钟
    }
}