package com.whitesoul.xiuxiantalent.talent.sub

import org.bukkit.Material
import org.bukkit.entity.EntityType
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.player.PlayerMoveEvent
import org.bukkit.scheduler.BukkitTask
import org.bukkit.util.Vector
import java.util.*

object GaoShanLiuShui: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }
    @EventHandler
    fun onPlayerMove(event: PlayerMoveEvent) {
        val player = event.player

        // 检查玩家是否下到了水中
        if (player.location.block.type == Material.WATER && cache.contains(player.uniqueId)) {
            // 在玩家附近召唤一只鸡
            val chickenLocation = player.location.clone().add(Vector(2.0, 1.0, 2.0))
            player.world.spawnEntity(chickenLocation, EntityType.CHICKEN)
        }
    }
}