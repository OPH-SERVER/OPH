package com.whitesoul.xiuxiantalent

import com.whitesoul.xiuxiantalent.commands.MainCommand
import com.whitesoul.xiuxiantalent.listener.PlayerListener
import com.whitesoul.xiuxiantalent.talent.TalentManager
import com.whitesoul.xiuxiantalent.talent.sub.DianShiChengJin
import com.whitesoul.xiuxiantalent.ui.TalentUiListener
import com.whitesoul.xiuxiantalent.util.initTalentItemList
import com.whitesoul.xiuxiantalent.util.talentItemList
import org.bukkit.Bukkit
import org.bukkit.configuration.file.YamlConfiguration
import org.bukkit.plugin.Plugin
import org.bukkit.plugin.java.JavaPlugin
import java.io.File

var instance: Plugin? = null
class XiuXianTalent: JavaPlugin() {
    override fun onEnable() {
        instance = this
        saveResource("playerData.yml", false)
        getCommand("zztf")?.setExecutor(MainCommand())
        Bukkit.getPluginManager().registerEvents(TalentUiListener(), this)
        Bukkit.getPluginManager().registerEvents(PlayerListener(), this)
        val start = System.currentTimeMillis()
        initTalentItemList()
        TalentManager().registerTalents()
        TalentManager().registerEvents(this)
        println("成功加载 ${talentItemList.size} 个天赋 共耗时: ${System.currentTimeMillis() - start}ms")

    }

    override fun onDisable() {
        // Plugin shutdown logic
    }
}
fun getPlayerDataFile(): YamlConfiguration {
    return YamlConfiguration.loadConfiguration(File(instance?.dataFolder, "playerData.yml"))
}
