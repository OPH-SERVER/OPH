package com.whitesoul.xiuxiantalent.talent.sub

import com.whitesoul.xiuxiantalent.instance
import com.whitesoul.xiuxiantalent.util.buildItem
import org.bukkit.Bukkit
import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.scheduler.BukkitTask
import java.util.*

object BaiMaGuiShu {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){
        for (uuid in cache) {
            if (taskCache[uuid] == null) {
                taskCache[uuid] = Bukkit.getScheduler().runTaskTimer(instance!!, Runnable {
                    val item = buildItem(Material.PAPER,"&c九阶灵石", arrayListOf(""))
                    item.amount = 30
                    Bukkit.getPlayer(uuid)?.inventory?.addItem(item)
                },20L * (80L *  60L),20L * (80L *  60L) )
            }
        }
    }
}