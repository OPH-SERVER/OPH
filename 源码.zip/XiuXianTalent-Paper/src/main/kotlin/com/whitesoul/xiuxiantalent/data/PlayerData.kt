package com.whitesoul.xiuxiantalent.data

import org.bukkit.entity.Player
import java.util.*
import kotlin.collections.HashMap

object PlayerData {
    // 存储玩家抽取次数
    private val playerCount = HashMap<UUID,Int>()
    // 存储玩家天赋
    private val playerTalent = HashMap<UUID,MutableList<String>>()
    // 获取玩家抽取次数
    fun getPlayerCount(player: Player): Int? {
        val uuid = player.uniqueId
        return playerCount[uuid]
    }
    // 添加玩家抽取次数
    fun addPlayerCount(player: Player, count: Int) {
        val uuid = player.uniqueId
        playerCount[uuid] = playerCount.getOrDefault(uuid,0).plus(count)
    }
    // 减少玩家抽取次数
    fun reducePlayerCount(player: Player, count: Int) {
        val uuid = player.uniqueId
        playerCount[uuid] = playerCount.getOrDefault(uuid,0).minus(count)
    }
    // 设置玩家抽取次数
    fun setPlayerCount(player: Player, count: Int) {
        val uuid = player.uniqueId
        playerCount[uuid] = count
    }
    // 获取玩家天赋
    fun getPlayerTalent(player: Player): MutableList<String>? {
        val uuid = player.uniqueId
        return playerTalent[uuid]
    }
    // 添加玩家天赋
    fun addPlayerTalent(player: Player, talent: MutableList<String>) {
        val uuid = player.uniqueId
        playerTalent[uuid] = talent
    }
    // 删除玩家天赋
    fun removePlayerTalent(player: Player, talent: String) {
        val uuid = player.uniqueId
        playerTalent[uuid]?.remove(talent)
    }
}