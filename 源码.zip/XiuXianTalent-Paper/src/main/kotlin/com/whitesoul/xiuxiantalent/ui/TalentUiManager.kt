package com.whitesoul.xiuxiantalent.ui

import com.whitesoul.xiuxiantalent.data.PlayerData
import com.whitesoul.xiuxiantalent.util.talentItemList
import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.inventory.Inventory
import org.bukkit.inventory.ItemStack

object TalentUiManager {

    // 给界面添加物品
    fun addItems(inv: Inventory,player: Player) {
        // 添加玻璃板
        val glassItem = ItemStack(Material.GRAY_STAINED_GLASS_PANE)
        val glassItemMeta = glassItem.itemMeta
        glassItemMeta?.setDisplayName(" ")
        glassItem.setItemMeta(glassItemMeta)
        val glass = arrayOf(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 15, 16, 17, 18, 19, 20, 22, 24, 25, 26)
        for (i in glass) {
            inv.setItem(i, glassItem)
        }
        // 添加确认按钮
        val confirmItem = ItemStack(Material.GREEN_WOOL)
        val confirmItemMeta = confirmItem.itemMeta
        confirmItemMeta?.setDisplayName("§a确认选择")
        confirmItemMeta?.setLore(listOf("§c选择后不可更改,请谨慎选择！"))
        confirmItem.setItemMeta(confirmItemMeta)
        inv.setItem(23, confirmItem)
        // 添加重置按钮
        val resetItem = ItemStack(Material.RED_WOOL)
        val resetItemMeta = resetItem.itemMeta
        resetItemMeta?.setDisplayName("§e重置选择")
        resetItemMeta?.setLore(listOf("§f你还剩下 §b${PlayerData.getPlayerCount(player)} §f次机会！"))
        resetItem.setItemMeta(resetItemMeta)
        inv.setItem(21, resetItem)
    }

    // 打开一个天赋界面
    fun openTalentUi(player: Player) {
        val inv = TalentHolder.inventory
        addItems(inv,player)
        player.openInventory(inv)
    }

    // 随机抽取
    fun randomTalent(inv: Inventory) {
            val itemCache = mutableListOf<ItemStack>()
            itemCache.addAll(talentItemList)
            val item = itemCache.random()
            inv.setItem(12, item)
            itemCache.remove(item)
            val item1 = itemCache.random()
            inv.setItem(13, item1)
            itemCache.remove(item1)
            val item2 = itemCache.random()
            inv.setItem(14, item2)

    }
}