package com.whitesoul.xiuxiantalent.talent.sub

import com.whitesoul.xiuxiantalent.instance
import org.bukkit.Bukkit
import org.bukkit.Effect
import org.bukkit.entity.LivingEntity
import org.bukkit.entity.Player
import org.bukkit.event.Listener
import org.bukkit.potion.PotionEffect
import org.bukkit.potion.PotionEffectType
import org.bukkit.scheduler.BukkitTask
import java.util.*

object ZhanShi:Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }

    // 注册天赋
    fun register() {
        Bukkit.getScheduler().runTaskTimer(instance!!, Runnable {
            for(uuid in getPlayer()) {
                val player = Bukkit.getPlayer(uuid)
                if (player != null) {
                    val playerLocation = player.location
                    val radius = 2.5 // 5x5 范围的一半
                    for (entity in player.world.getNearbyEntities(playerLocation, radius, radius, radius)) {
                        if (entity is LivingEntity && entity != player) {
                            applyPoisonEffect(entity)
                        }
                    }
                }
            }
        },20L,20L)
    }
    private fun applyPoisonEffect(entity: LivingEntity) {
        entity.addPotionEffect(PotionEffect(PotionEffectType.POISON, 20 * 20, 0, false, false)) // 持续 20 秒
    }
}