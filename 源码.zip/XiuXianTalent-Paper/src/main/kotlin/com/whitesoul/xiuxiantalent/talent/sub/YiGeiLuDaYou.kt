package com.whitesoul.xiuxiantalent.talent.sub

import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.entity.EntityDamageEvent
import org.bukkit.potion.PotionEffect
import org.bukkit.potion.PotionEffectType
import org.bukkit.scheduler.BukkitTask
import java.util.*

object YiGeiLuDaYou: Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }

    // 注册天赋
    fun register() {

    }

    @EventHandler
    fun onPlayerDamage(event: EntityDamageEvent) {
        if (event.entity is Player) {
            val player = event.entity as Player

            // 检查玩家的血量是否低于10
            if (player.health < 10 && cache.contains(player.uniqueId)) {
                // 给予玩家速度10、跳跃提升10和缓降1效果
                player.addPotionEffect(PotionEffect(PotionEffectType.SPEED, 60 * 20, 9)) // 速度10,持续1分钟
                player.addPotionEffect(PotionEffect(PotionEffectType.JUMP_BOOST, 60 * 20, 9)) // 跳跃提升10,持续1分钟
                player.addPotionEffect(PotionEffect(PotionEffectType.SLOW_FALLING, 60 * 20, 0)) // 缓降1,持续1分钟

                // 向玩家发送一条消息
                player.sendMessage("§c你的生命值很低,获得了一些增益效果。")
            }
        }
    }
}