package com.whitesoul.xiuxiantalent.talent.sub

import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.player.PlayerItemHeldEvent
import org.bukkit.inventory.ItemStack
import org.bukkit.scheduler.BukkitTask
import java.util.*

object HeShen:Listener {
    private val cache = mutableListOf<UUID>()
    private val taskCache = HashMap<UUID, BukkitTask>()

    /// 增加
    fun addPlayer(player: Player) {
        val uuid = player.uniqueId
        cache.add(uuid)
    }

    /// 减少
    fun removePlayer(player: Player) {
        val uuid = player.uniqueId
        cache.remove(uuid)
    }

    // 获取
    fun getPlayer(): MutableList<UUID> {
        return cache
    }
    // 注册天赋
    fun register(){

    }
    @EventHandler
    fun onPlayerItemHeldEvent(event: PlayerItemHeldEvent) {
        val player = event.player
        val inventory = player.inventory
        // 检查背包中是否有石斧头
        if (cache.contains(player.uniqueId) && inventory.contains(Material.STONE_AXE)) {
            // 给予玩家铁斧头和金斧头
            inventory.addItem(ItemStack(Material.IRON_AXE, 1))
            inventory.addItem(ItemStack(Material.GOLDEN_AXE, 1))
        }
    }
}